Cartaj-3W - Classification of ThreeWay Junctions of RNA
=======================================================

Requirements:
-------------
	Ruby (tested with versions 1.8.7 and 1.9.2)

Usage:
------
	This program can be used in the following ways:

	1) By providing the junction in a text file:
	   # ./run.sh [-d|-s] junction
	   If neither -d or -s options is provided, -d is assumed.

	2) By entering the junction manually:
	   # ./run.sh (-d|-s)
	   Please enter your junction in dotbracket format:
	   ....
	   Ctrl-D to finish

	3) By piping the junction in the command:
	   cat file | ./run.sh (-d|-s)

Input format:
-------------

-d or --dotbracket

   The three strands are separated by three underscore characters:
   AAAAAA___UUCC___GGCCUUU
   (((.((___))((___))..)))

   The structure given must be a threeway junction (three helices linked
   by unpaired strands), or the score computation might be wrong. If the
   non-helix parts contain watson-crick links, please remove them or
   use the format below instead.

-s or --sequence

   Since the structure of a threeway junction is well defined, there
   is no need for the complexity of the dotbracket notation. There are
   three strands, each made of three parts: first helix, unpaired strand,
   second helix. In this format, each strand is provided on one line, and
   the three parts of a strand are separated by dots.

   Here is the same junction as above:
   AAA.A.AA
   UU..CC
   GG.CC.UUU

Understanding the output:
-------------------------

The result looks like the following table:

---------------------------------------------------------
Fam.	Rot.	Bonus	Term.	Junc.	Stack.	Total
A	0	1.00	0.00	-4.00	10.00	0.538462
B	0	0.00	0.00	-1.00	10.00	0.818182
C	0	0.00	0.00	4.00	10.00	1.555556
A	1	1.50	0.00	-1.00	0.53	0.068889
B	1	0.00	0.00	5.00	0.53	0.425641
C	1	0.00	0.00	1.00	0.53	0.095833
A	2	2.00	0.00	5.00	2.00	1.285714
B	2	0.00	0.00	-2.00	2.00	0.000000
C	2	0.00	0.00	-5.00	2.00	-0.166667
---------------------------------------------------------

This was computed for this junction (in the examples folder):
1) CCC..GG
2) CC.A.UA
3) AU.CGGUA.GGG

The 9 lines of the table correspond to the following 9 possible
configurations:
A,0: family A, stacking on strand 1
B,0: family B, stacking on strand 1
C,0: family C, stacking on strand 1
A,1: family A, stacking on strand 3
B,1: family B, stacking on strand 3
C,1: family C, stacking on strand 3
A,2: family A, stacking on strand 2
B,2: family B, stacking on strand 2
C,2: family C, stacking on strand 2

(The "Rot." number is the number of clockwise rotations you have to perform
to put the stacking strand in first position)

For each configuration, the score of each criterion is given, and then
a total score. For prediction purposes you should only look at the total
score (the higher the better), but the other scores are given for
troubleshooting purposes.
