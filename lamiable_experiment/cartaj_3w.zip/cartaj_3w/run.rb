#!/usr/bin/env ruby

"$LastChangedRevision: 14 $" =~ /(\d+)/
REVISION = $1.to_i
"$Date: 2011-05-24 15:53:12 +0200 (mar. 24 mai 2011) $" =~ /Date: (....-..-..)/
DATE=$1

unless respond_to?(:require_relative)
  def require_relative(arg)
    require(File.expand_path(File.join(File.dirname(__FILE__), arg)))
  end
end

require_relative 'src/configuration.rb'
require_relative 'src/brin.rb'
require_relative 'src/motif.rb'
require_relative 'src/eval.rb'
require_relative 'src/tests_qst.rb'
require_relative 'src/report.rb'

include Classification::ThreeWay
TESTS = [Tests::TestStacking, Tests::TestJonctions,
         Tests::TestBonus, Tests::TestTerminaux]
COEFFICIENTS = [1.0, 1.0, 1.0, 2.0]

require 'getoptlong'
options = GetoptLong.new(['-h', '--help', GetoptLong::NO_ARGUMENT],
                         ['-d', '--dotbracket', GetoptLong::NO_ARGUMENT],
                         ['-s', '--sequence', GetoptLong::NO_ARGUMENT],
                         ['-v', '--version', GetoptLong::NO_ARGUMENT]
                         )

def help
  print "Usage: #{$0} [OPTIONS] [FORMAT: -d|-s] [file]\n"
  print "FORMAT:\n"
  print " -d\t--dotbracket\tEnter the junction in dotbracket notation [default]\n"
  print " -s\t--sequence\tEnter the junction in sequence notation (see documentation)\n"
  print "OPTIONS:\n"
  print " -h\t--help\t\tDisplays this help\n"
  print " -v\t--version\tDisplays this current revision and revision date\n"
end

if ARGV.length == 0
  help
  exit(1)
end

mode = :db
separator = '___'
motif = nil

options.each { |opt, arg|
  case opt
  when '-h'
    help
    exit(0)
  when '-d'
    mode = :db
  when '-s'
    mode = :seq
  when '-v'
    print "Revision #{REVISION} (#{DATE})\n"
    exit(0)
  else
    help
    exit(1)
  end
}

if ARGV[0]
  begin
    f = File.new(ARGV[0], 'r')
    motif = if mode == :seq
              Motif.from_seq(f)
            else
              sequence, brackets = f.readlines
              Motif.from_dotbracket(sequence, brackets, separator)
            end
    f.close
  rescue
    $stderr.print $!, "\n"
    exit(2)
  end
else
  print "Please enter your junction in #{mode==:db ? 'dotbracket' : 'sequence'} format:\n"
  begin
    str = ''
    while l = gets
      str << l
    end
    motif = if mode == :seq
              Motif.from_seq(str)
            else
              sequence, brackets = str.split("\n")
              Motif.from_dotbracket(sequence, brackets, separator)
            end
  rescue
    $stderr.print $!, "\n"
    exit(2)
  end
end

eval = Evaluations::EvalPlusRangs.new
TESTS.each_with_index { |t, i|
  eval.ajoute_test(t.new, COEFFICIENTS[i])
}

eval.calcule(motif)
print eval.to_s
