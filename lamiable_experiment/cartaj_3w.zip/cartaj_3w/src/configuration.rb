module Classification
  module ThreeWay

    class Configuration

      F = %w{A B C}.freeze
      R = (0..2).to_a.freeze

      def self.each
        F.each { |f|
          R.each { |r|
            yield(f, r)
          }
        }
      end

      def self.each_f
        F.each { |f|
          yield(f)
        }
      end

      def self.each_r
        R.each { |f|
          yield(f)
        }
      end

      def self.nombre_de_possibilites
        F.size * R.size
      end

    end

  end
end
