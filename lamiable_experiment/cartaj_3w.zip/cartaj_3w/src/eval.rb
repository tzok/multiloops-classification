module Classification
  module ThreeWay

    module Tests
      class Test
        
        def calcule(motif, famille, rotation)
          raise 'classe abstraite. cette methode doit etre redefinie'
        end
        
        def nom
          self.class.name
        end

      end
    end

    module Evaluations

      class Evaluation

        attr_reader :tests, :eval, :valeurs, :coefs, :worst_value

        def initialize
          @worst_value = - 1_000_000
          @eval = nil
          @tests = {}
          @coefs = {}
        end

        def ajoute_test(test, coef = 1.0)
          @tests[test.nom] = test
          @coefs[test.nom] = coef
        end

        def calcule(motif, my_coefs = nil)
          @eval = {}
          @tests.each_value { |test|
            @eval[test.nom] ||= {}
            Configuration.each { |f, r|
              @eval[test.nom][f] ||= []
              @eval[test.nom][f][r] = test.calcule(motif, f, r)
            }
          }

          evalue(my_coefs)
        end

        def evalue(my_coefs = nil)
          if my_coefs
            old_coefs = @coefs
            @coefs = my_coefs.dup
          end

          total = calcule_evaluation

          if my_coefs
            @coefs = old_coefs
          end
          return total
        end

        def calcule_evaluation
          @valeurs = {}
          Configuration.each { |f, r|
            @valeurs[f] ||= {}
            total = 0.0
            @tests.each_value { |test|
              total += @coefs[test.nom] * @eval[test.nom][f][r].to_f
            }
            @valeurs[f][r] = total
          }
        end

        def meilleur
          m = nil
          g = @worst_value
          Configuration.each { |f, r|
            h = valeurs[f][r]
            if cmp(g, h)
              g = h
              m = [f, r]
            end
          }

          m
        end

        def meilleur_contient?(fam, rot)
          # trouve le meilleur score
          g = @worst_value
          Configuration.each { |f, r|
            h = valeurs[f][r]
            if cmp(g, h)
              g = h
            end
          }

          g = g.round_to(3)

          # liste des configurations ayant ce score
          c = []
          Configuration.each { |f, r|
            h = valeurs[f][r]
            if h.round_to(3) == g
              c << [f, r]
            end
          }

          # contient ou pas ?
          return c.include?([fam, rot])
        end

        def resultats_tries
          a = []
          Configuration.each { |f, r|
            a << [valeurs[f][r], [f,r]]
          }
          a.sort! { |t1, t2| if is_better?(t1[0], t2[0])
                               -1
                             elsif t1[0] == t2[0]
                               0
                             else
                               1
                             end
          }
        end

        def meilleur_pour_la_rotation(r)
          m = nil
          g = @worst_value
          Configuration.each_f { |f|
            h = valeurs[f][r]
            if cmp(g, h)
              g = h
              m = [f, r]
            end
          }

          m
        end

        def to_s
          s = self.headers
          Configuration.each_r { |r|
            Configuration.each_f { |f|
              s << self.to_s2(f, r)
            }
          }
          s
        end
        
        def headers
          s = "Fam.\tRot.\t"
          @tests.each_key { |k| s << k << "\t" }
          s << "Total\n"
        end

        def to_s2(f, r)
          s = "#{f}\t#{r}\t"
          @tests.each { |k, t|
            s << '%.2f' % @eval[k][f][r] << "\t"
          }
          s << "#{'%f' % @valeurs[f][r]}\n"
          s
        end

        def rang(f, r)
          rang = 1
          v = @valeurs[f][r]
          Configuration.each { |f2, r2|
            i = 0
            e = @valeurs[f2][r2]
            if cmp(v, e)
              rang += 1
            end
            i += 1
          }
          return rang
        end

        def cmp(a, b)
          a < b
        end

        def is_better?(a, b)
          ! cmp(a, b)
        end

      end

      class EvalAvecRatio < Evaluation

        def initialize
          super()
          @worst_value = 1000
        end

        def calcule_evaluation
          @valeurs = {}
          Configuration.each { |f, r|
            @valeurs[f] ||= {}
            total = 0.0
            @tests.each_value { |test|
              total += @coefs[test.nom] * @eval[test.nom][f][r].to_f
            }

            rang_terminaux = 1
            rang_jonctions = 1
            Configuration.each { |f2, r2|
              e = @eval['Term.']
              if e[f][r] < e[f2][r2]
                rang_terminaux += 1
              end
              e = @eval['Junc.']
              if e[f][r] < e[f2][r2]
                rang_jonctions += 1
              end
            }

            @valeurs[f][r] = (rang_terminaux+rang_jonctions).to_f/total
          }
        end  

        def cmp(a, b)
          if a >= 0.0 && b >= 0.0
            a > b
          else
            a <= 0.0
          end
        end

      end

      class EvalPlusRangs < Evaluation

        def calcule_evaluation
          @valeurs = {}
          Configuration.each { |f, r|
            @valeurs[f] ||= {}
            total = 0.0
            @tests.each_value { |test|
              total += @coefs[test.nom] * @eval[test.nom][f][r].to_f
            }

            rangs = Array.new(@tests.size) { 1 }
            Configuration.each { |f2, r2|
              i = 0
              @tests.each { |k, t|
                #next if k == 'Bonus' && f == 'B'
                next if @coefs[t.nom] == 0.0
                e = @eval[k]
                if e[f][r] < e[f2][r2]
                  rangs[i] += 1
                end
                i += 1
              }
            }

            diviseur = 0 
            rangs.each_with_index { |rr, i| diviseur += rr }
            @valeurs[f][r] = total / diviseur
          }

        end  

      end

      # comme EvalPlusRangs mais n'augmente pas le rang
      # en cas d'egalite. CAD si on est apres deux configurations
      # de rangs 3, on n'est pas 3e, on est 2e.
      class EvalPlusRangs2 < Evaluation

        def calcule_evaluation
          @valeurs = {}
          Configuration.each { |f, r|
            @valeurs[f] ||= {}
            total = 0.0
            @tests.each_value { |test|
              total += @coefs[test.nom] * @eval[test.nom][f][r].to_f
            }

            rangs = Array.new(@tests.size) { 1 }
            seen = {}
            Configuration.each { |f2, r2|
              i = 0
              @tests.each { |k, t|
                e = @eval[k]
                if e[f][r] < e[f2][r2] && seen[e[f2][r2]].nil?
                  seen[e[f2][r2]] = true
                  rangs[i] += 1
                end
                i += 1
              }
            }

            diviseur = 0 
            rangs.each_with_index { |rr, i| diviseur += rr }
            @valeurs[f][r] = total / diviseur
          }
        end  

      end

    end

  end
end
