class Brin

  attr_accessor :debut, :avant, :jonction, :apres

  include Enumerable

  def initialize(id_nucleotide = -1)
    @debut = id_nucleotide.to_i
    @avant = []
    @jonction = []
    @apres = []
  end

  def each
    @avant.each { |n| yield(n) }
    @jonction.each { |n| yield(n) }
    @apres.each { |n| yield(n) }
  end

  def each_id
    self.size.times { |i| yield(@debut+i) }
  end

  def jonction_ids
    (@debut + @avant.size)..(@debut + @avant.size + @jonction.size)
  end

  def split_ids
    [@debut...(@debut+@avant.size),
     (@debut+@avant.size)...(@debut + @avant.size + @jonction.size),
     (@debut + @avant.size + @jonction.size)...(@debut + @avant.size + @jonction.size+@apres.size)]
  end

  def join(separateur='')
    self.map{|i| i.to_s}.join(separateur)
  end

  def [](i)
    raise "#{i}: position hors du tableau" if i<0

    if i < @avant.size
      @avant[i]
    elsif i < @avant.size + @jonction.size
      @jonction[i - @avant.size]
    elsif i < @avant.size + @jonction.size + @apres.size
      @apres[i - @avant.size - @jonction.size]
    else
      raise "#{i}: position hors du tableau"
    end
  end

  def size
    @avant.size + @jonction.size + @apres.size
  end

  def last_WC5_p
    @avant.size - 1
  end
  
  def last_WC3_p
    @avant.size + @jonction.size
  end

  def last_WC5_id
    last_WC5_p + @debut
  end
  
  def last_WC3_id
    last_WC3_p + @debut
  end

  def fin
    debut+size-1
  end

  def include?(id)
    id >= debut && id <= fin
  end

end
