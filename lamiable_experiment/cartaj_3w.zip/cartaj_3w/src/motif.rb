def i2n(i)
  case i
  when 2
    'A'
  when 3
    'C'
  when 4
    'G'
  when 5
    'U'
  else
    'X'
  end
end

def n2i(n)
  case n
  when 'A'
    2
  when 'C'
    3
  when 'G'
    4
  when 'U'
    5
  else
    1
  end
end

def complementaire?(a, b)
  %w{AU UA GC CG GU UG}.include?(a+b)
end

class Motif

  attr_reader(:brins, :id_motif, :nb_brins,
              :vraie_famille)
  attr_writer :nb_brins, :id_motif

  def initialize(filename = nil)
    @brins = []
    @id_motif = -1
    @nb_brins = 0
    @brins = []
    return if filename.nil?

    if filename =~ /_Fam_([ABC])_/
      @vraie_famille = $1
    end

    f = File.new(filename, 'r')
    @id_motif, @nb_brins, size = f.readline.split.map { |s| s.to_i }

    @nb_brins.times {
      l = f.readline
      while l =~ /^\s*$/
        l = f.readline
      end

      count = l.split.map { |s| s.to_i }
      if count[0] != count[1] + count[2] + count[3]
        raise 'Donnees incoherentes'
      end

      b = Brin.new(f.readline.to_i)
      @brins << b
      row = f.readline.split.map { |s| s.to_i }
      if row.size != count[0]
        raise 'Donnees incoherentes'
      end

      count[1].times { b.avant << (i2n row.shift) }
      count[2].times { b.jonction << (i2n row.shift) }
      count[3].times { b.apres << (i2n row.shift) }
    }

    f.close
  end

  def self.from_seq(str)
    m = Motif.new
    str.each_line { |line|
      line.chomp!
      a = line.split('.')
      b = Brin.new(-1)
      b.avant = a[0].split(//)
      b.jonction = a[1].split(//)
      b.apres = a[2].split(//)
      m.brins << b
    }
    m.nb_brins = m.brins.size
    m.id_motif = -1
    return m
  end

  def self.from_dotbracket(sequence, brackets, separator = '___')
    m = Motif.new
    sa = sequence.split(separator)
    ba = brackets.split(separator)
    sa.size.times { |ib|
      seq = sa[ib]
      bra = ba[ib]
      b = Brin.new(-1)
      i = 0
      while bra[i, 1] =~ /[()]/
        b.avant << seq[i, 1] unless seq[i, 1] == '-'
        i += 1
      end
      while bra[i, 1] == '.'
        b.jonction << seq[i, 1] unless seq[i, 1] == '-'
        i += 1
      end
      while i < seq.size
        b.apres << seq[i, 1] unless seq[i, 1] == '-'
        i += 1
      end
      m.brins << b
    }

    # corrige les brins dont la jonction
    # est de longueur 0
    m.brins.each_with_index { |b, i|
      j = if i == m.brins.size-1
            0
          else
            i+1
          end
      b2 = m.brins[j]
      s = b2.avant.size
      if (s > b.apres.size && b.apres.size == 0)
        b.apres = b.avant[b.avant.size-s...b.avant.size]
        b.avant = b.avant[0..b.avant.size-s-1]
      end
    }

    # termine
    m.nb_brins = m.brins.size
    m.id_motif = -1
    return m
  end

  def self.from_graph(g)
    m = Motif.new
    k = g.nodes.keys.sort
    g.unflag

    while s = k.find { |i| g[i].flag == nil }
      s = g[s]
#p :avant
#p s.id
      b = Brin.new(s.id)
      a = b.avant
      a << s.label
      s.flag = true
      while s = g[s.id+1]
#p s.id
        s.flag = true
        if a == b.jonction
          unless g.filter_edges(s.id, WC_WC_CIS).empty?
            unless g.filter_edges(s.id+1, WC_WC_CIS).empty?
            a = b.apres
#p :apres
            end
          end
        elsif g.filter_edges(s.id, WC_WC_CIS).empty?
          if a == b.avant
            a = b.jonction
#p :jonction
          else
            raise 'error'
          end
        end
        a << s.label
      end
      m.brins << b
    end
    
    return m
  end

  def size
    @brins.inject(0) { |n, brin| brin.size + n }
  end

  def jonction(i)
    @brins[i].jonction
  end

  def last_WC5(i)
    @brins[i].avant.last
  end
  
  def last_WC3(i)
    @brins[i].apres.first
  end

  def last_WC5_p(i)
    @brins[i].last_WC5_p
  end
  
  def last_WC3_p(i)
    @brins[i].last_WC3_p
  end

  def last_WC5_id(i)
    @brins[i].last_WC5_id
  end
  
  def last_WC3_id(i)
    @brins[i].last_WC3_id
  end

  def invalid?
    brins.each { |b|
      return true if b.avant.size == 0 || b.apres.size == 0
    }
    false
  end

  # True if the 'other' motif is contained inside this one.
  # For each strand in other, we search the corresponding
  # strand in self. If no such strand is found, return false.
  def includes?(other)
    if other.kind_of?(Numeric)
      @brins.each { |b|
        if b.include?(other)
          return true
        end
      }
      return false
    else
      a = @brins.map { |b| (b.debut .. b.fin) }
      other.brins.each { |b|
        found = false
        a.each { |range|
          if range.include?(b.debut) && range.include?(b.fin)
            found = true
          end
        }
        unless found
          return false
        end
      }
      return true
    end
  end
  alias :include? :includes?

  def overlaps_with?(other)
    a = @brins.map { |b| (b.debut .. b.fin) }
    other.brins.each { |b|
      a.each { |range|
        if range.include?(b.debut) && range.include?(b.fin)
          return true
        end
      }
    }
    return false
  end

  def name
    @brins.map{|b|b.debut}.join(',')
  end

  def fix_helix_ends
    changed_something = true
    while changed_something
      changed_something = false
      @brins.each_with_index { |b, i|
        b2 = brin_complementaire(i)
        next if b.avant.empty? || b2.apres.empty?
        if !complementaire?(b.avant.last, b2.apres.first)
          b.jonction.unshift(b.avant.last)
          b.avant.pop
          b2.jonction.push(b2.apres.first)
          b2.apres.shift
          changed_something = true
        end
      }
    end
  end

  def to_s
    s = "-1 #{@brins.size} #{@size}\n"
    @brins.each { |b|
      s << "#{b.size} #{b.avant.size} #{b.jonction.size} #{b.apres.size}\n#{b.debut}\n"
      b.each { |n| s << (n2i n).to_s + ' ' }
      s << "\n"
    }
    return s
  end

  def to_seq(rotation = 0)
    a = []
    i = (@brins.size - rotation) % @brins.size
    i.upto(@brins.size-1) { |j|
      a << @brins[j]
    }
    0.upto(i-1) { |j|
      a << @brins[j]
    }
    a.map { |b|
      [b.avant, b.jonction, b.apres].map{ |l| l.join }.join('.')
    }.join("\n")
  end

  # idem que to_seq mais en ne prenant que la derniere paire
  # de bases des helices. Utile pour la comparaison de deux
  # motifs
  def to_short_seq(rotation=0)
    a = []
    i = (@brins.size - rotation) % @brins.size
    i.upto(@brins.size-1) { |j|
      a << @brins[@brins.size-1]
    }
    0.upto(i-1) { |j|
      a << @brins[j]
    }
    a.map { |b|
      [[b.avant.last], b.jonction, [b.apres.first]].map{ |l| l.join }.join('.')
    }.join("\n")
  end

  def to_dotbracket(pad = 'A'*6, show_id = false, prefix='')
    s = ''+prefix
    if show_id
      @brins.each { |b|
        id = (b.debut % MAX_ID).to_s
        s << id
        s << ' '*((b.size+pad.size) - id.size)
      }
      s << "\n#{prefix}"
    end
    s << @brins.map{|b| b.join}.join(pad) + "\n"
    s << prefix
    s << '('*@brins[0].avant.size
    s << '.'*@brins[0].jonction.size
    s << '('*@brins[0].apres.size
    s << pad
    1.upto(@brins.size-2) { |i|
      s << ')'*@brins[i].avant.size
      s << '.'*@brins[i].jonction.size
      s << '('*@brins[i].apres.size
      s << pad
    }
    s << ')'*@brins.last.avant.size
    s << '.'*@brins.last.jonction.size
    s << ')'*@brins.last.apres.size

    s << "\n"
  end

  # Export au format de motifs utilise dans Classification-2-ways
  def to_mot2w_qst
    assert { @brins.size == 2 }
    sz = self.size
    s = "2 #{sz}\n"
    self.each_id { |id| s << "#{id} " }
    s << "\n"

    # construit une matrice d'adjacence du motif
    m = Array.new(sz) { Array.new(sz) { 0 } }
    i = 0
    self.each { |n|
      m[i][i] = n2i(n)
      i += 1
    }

    @brins[0].avant.each_with_index { |n, i|
      m[sz-i-1][i] = WC_WC_CIS
      m[i][sz-i-1] = WC_WC_CIS
    }

    off = @brins[0].avant.size + @brins[0].jonction.size
    off2 = @brins[1].apres.size + @brins[1].jonction.size
    @brins[0].apres.each_with_index { |n, i|      
      m[sz-i-1-off2][i+off] = WC_WC_CIS
      m[i+off][sz-i-1-off2] = WC_WC_CIS
    }

    m.each { |row|
      s << row.join(' ') << "\n"
    }
    s << "\n"
  end

  def ids(pad = nil)
    a = []
    @brins.each { |b|
      b.each_id { |i| a << i }
      if pad
        a.concat(pad)
      end
    }
    a
  end

  def each_id
    @brins.each { |b| b.each_id { |id| yield(id) } }
  end

  def each
    @brins.each { |b| b.each { |n| yield(n) } }
  end

  def ajout_brin(b)
    @brins << b
    @nb_brins += 1
  end

  def brin_complementaire(i)
    j = if i == 0
          self.brins.size - 1
        else
          i - 1
        end
    self.brins[j]
  end

  def liaison_wc(brin_id, position)
    b = self.brins[brin_id]
    id = b[position]
    if b.avant.include?(id)
      b2 = brin_complementaire(brin_id)
      return b2[b2.size-position-1]
    elsif b.apres.include?(id)
      b2 = self.brins[ (brin_id+1) % self.brins.size ] 
      return b2[b.size-position-1]
    else
      nil
    end
  end

  def liaison_wc_p(brin_id, position)
    begin
      b = self.brins[brin_id]
      id = b[position]
      if b.avant.include?(id)
        b2 = brin_complementaire(brin_id)
        return b2.size-position-1
      elsif b.apres.include?(id)
        return b.size-position-1
      else
        return -1
      end
    rescue
      return -1
    end
  end

  def liaison_wc_id(brin_id, position)
    b = self.brins[brin_id]
    id = b[position]
    if b.avant.include?(id)
      b2 = brin_complementaire(brin_id)
      return b2.debut + (b2.size-position-1)
    elsif b.apres.include?(id)
      b2 = self.brins[ (brin_id+1) % self.brins.size ] 
      return b2.debut + (b.size-position-1)
    else
      -1
    end
  end

  def ecarts_positions_terminaux
    a = []
    brins.each_with_index { |b, i|
      b2 = brin_complementaire(i)
      id1 = b.last_WC5_id
      id2 = b.last_WC3_id
      a << (id1-id2)
    }
    return a
  end
end
