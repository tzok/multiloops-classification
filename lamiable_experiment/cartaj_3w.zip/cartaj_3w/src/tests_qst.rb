# -*- coding: iso-8859-1 -*-
module Classification
  module ThreeWay

    module Tests

      class TestStacking < Test
        
        def calcule(motif, famille, rotation)
          a = motif.jonction(0).size
          b = motif.jonction(2).size
          c = motif.jonction(1).size

          sa = 1.0/(1+a)
          sb = 1.0/(1+b)
          sc = 1.0/(1+c)
          if (a<=b) then sb += 1.0/(1+b-a) else  sa += 1.0/(1+a-b) end
          if (b<=c) then sc += 1.0/(1+c-b) else  sb += 1.0/(1+b-c) end
          if (c<=a) then sa += 1.0/(1+a-c) else  sc += 1.0/(1+c-a) end

          if (a<=b) then sa += 1 else sb += 1 end
          if (b<=c) then sb += 1 else sc += 1 end
          if (c<=a) then sc += 1 else sa += 1 end

          sa = 10.0 if a == 0
          sb = 10.0 if b == 0
          sc = 10.0 if c == 0

          return case rotation
                 when 0
                   sa
                 when 1
                   sb
                 when 2
                   sc
                 end
        end

        def nom
          'Stack.'
        end

      end

      class TestJonctions < Test
        def nom
          'Junc.'
        end

        def calcule(motif, famille, rotation)
          r_moins_b = motif.jonction((4-rotation)%3).size - motif.jonction((5-rotation)%3).size
          val = case famille
                when 'A'
                  r_moins_b
                when 'B'
                  r_moins_b.abs
                when 'C'
                  -r_moins_b
                end

          val = case famille
                when 'A'
                  val
                when 'B'
                  case val
                  when 0
                    5.0
                  when 1
                    5.0
                  when 2
                    1.0
                  else
                    3.0 - val
                  end
                when 'C'
                  extra_bleu = motif.jonction((5-rotation)%3).size - 5
                  extra_bleu = 0 if extra_bleu < 0
                  val + extra_bleu
                else
                  0.0
                end

          if val > 10.0
            return 10.0
          elsif val < -10.0
            return -10.0
          else
            return val
          end
        end

      end

      class TestBonus < Test

        def nom
          'Bonus'
        end

        def calcule(motif, famille, rotation)
          bonus = 0.0
          iV = (3-rotation)%3
          iR = (4-rotation)%3
          iB = (5-rotation)%3

          case famille
          when 'A'
            # bonus 1: sur la jonction rouge un A en 2,3,4 ou 5
            (motif.last_WC5_p(iR)+2).upto(motif.last_WC5_p(iR)+5) do |i|
              break if i >= motif.brins[iR].size
              if motif.brins[iR][i] == 'A'
                bonus += 1.0
                break
              end
            end

            # bonus 2: si en H2 apres le dernier WC on a A sur le vert et qqch sur le rouge
            #          si c'est un G sur le rouge, bonus suppl�mentaire
            first_non_WC_V3 = motif.last_WC3_p(iV)-1
            first_non_WC_R5 = motif.last_WC5_p(iR)+1
            if (motif.brins[iV][first_non_WC_V3] ==  'A')
              bonus += 1.0
              if motif.brins[iR][first_non_WC_R5] == 'G'
                bonus += 0.5
              end
            end

          when 'B'
            bonus = 0.0
          when 'Y'
            bonus = 1.0
          when 'C'
            # bonus 3: on a un mot de la forme AU, AAU, AUA sur la jonction
            # bleue qui commence en position 1, 2, 3 ou 4 apres le dernier WC en 3'
            first_non_WC_B3 = motif.last_WC3_p(iB)-1
            a = u = 0
            (first_non_WC_B3-1).downto(first_non_WC_B3-4) { |i|
              break if i < 0
              case motif.brins[iB][i]
              when 'A'
                a += 1
              when 'U'
                u += 1
              end
            }
            bonus = if a > 0
                      (a.to_f+u.to_f)/2.0
                    else
                      0.0
                    end
          end

          bonus
        end

      end

      class TestTerminaux < Test

        def nom
          'Term.'
        end

        def initialize(__R5V3 = nil, __B5R3 = nil, __V5B3 = nil)
          __R5V3 ||= [
                      [ 0, 0, 2],
                      [ 5, 4, 2],
                      [ 4, 2, 7],
                      [ 1, 1, 1],
                      [ 0, 0, 0],
                      [ 0, 0, 3],
                     ]
          
          __B5R3 ||= [
                      [ 1, 0, 0],
                      [ 6, 4, 3],
                      [ 3, 2, 5],
                      [ 0, 1, 6],
                      [ 0, 0, 1],
                      [ 0, 0, 0],
                     ]
          
          __V5B3 ||= [
                      [ 2, 1, 2],
                      [ 7, 3, 8],
                      [ 0, 2, 2],
                      [ 0, 1, 3],
                      [ 0, 0, 0],
                      [ 1, 0, 0],
                     ]
          k = 6;

          # initialisation des matrices
          @R5V3, @B5R3, @V5B3 = Array.new(3) { Array.new(6) { Array.new(3) } }
          
          0.upto(2) { |i|
            s = 0.0;
            0.upto(k-1) { |j| s += __R5V3[j][i] }
            0.upto(k-1) { |j| @R5V3[j][i] = (k*__R5V3[j][i] - s).to_f/(s*(k-1)) }
            s = 0.0
            0.upto(k-1) { |j| s += __B5R3[j][i] }
            0.upto(k-1) { |j| @B5R3[j][i] = (k*__B5R3[j][i] - s).to_f/(s*(k-1)) }
            s = 0.0
            0.upto(k-1) { |j| s += __V5B3[j][i] }
            0.upto(k-1) { |j| @V5B3[j][i] = (k*__V5B3[j][i] - s).to_f/(s*(k-1)) }
          }
        end

        def calcule(motif, famille, rotation)
          f = case famille
              when 'A'
                0
              when 'B'
                1
              when 'C'
                2
              end

          iV = (3-rotation)%3
          iR = (4-rotation)%3
          iB = (5-rotation)%3

          v5 = n2i motif.last_WC5(iV)
          r5 = n2i motif.last_WC5(iR)
          b5 = n2i motif.last_WC5(iB)

          v3 = n2i motif.last_WC3(iV)
          r3 = n2i motif.last_WC3(iR)
          b3 = n2i motif.last_WC3(iB)

          begin
            (@R5V3[get_row(r5,v3)][f] + @B5R3[get_row(b5,r3)][f] +
             @V5B3[get_row(v5,b3)][f]).to_f
          rescue
            0.0
          end
        end

        def print_coefs
          print "R5V3\n"
          @R5V3.each { |r|
            r.each { |c| print ' %8.4f' % c }
            print "\n"
          }
          print "B5R3\n"
          @B5R3.each { |r|
            r.each { |c| print ' %8.4f' % c }
            print "\n"
          }
          print "V5B3\n"
          @V5B3.each { |r|
            r.each { |c| print ' %8.4f' % c }
            print "\n"
          }
        end

        private
        def get_row(a, b)
          if a+b == 7
            a-2
          elsif i2n(a) == 'G' && i2n(b) == 'U'
            4
          elsif i2n(a) == 'U' && i2n(b) == 'G'
            5
          else raise 'error'
          end
        end
      end
    end
  end
end
