# -*- coding: iso-8859-1 -*-
module Classification
  module ThreeWay

    module Reports

      # Affiche les r�sultats de tous les tests pour tous
      # les motifs. Suppose que la methode d'evaluation, les
      # tests et les coefficients sont identiques pour chaque
      # motif.
      class Report

        def self.generate(h)
          [
            self.headers(h),

            self.sorted_keys(h).map { |motif|
              self.un_motif(motif, h[motif])
            },

            self.summary(h)
          ].flatten.join(self.separateur)
        end

        # Affiche les resultats en les regroupant par
        # nom de motif. A redefinir si on veut trier
        # suivant d'autres criteres
        def self.sorted_keys(h)
          h.keys.sort
        end

        def self.headers(h)
          e = h.values.first
          s = "Methode d'evaluation: #{e.class.name}\nTests:\n"
          e.tests.each { |nom, test|
            s << "\t" << nom << "\t%.2f" % e.coefs[nom] << "\n"
          }
          return s
        end

        def self.summary(h)
          vrai = 0

          ecart_moyen = 0.0
          ecart_moyen_2 = 0.0

          n = 0
          n2 = 0
          h.each { |motif, e|
            motif =~ FAMILY_R or raise 'nom de motif incorrect'
            famille = $1
            f, r = e.meilleur
            premier = (f == famille && r == 0)
            if premier
              vrai += 1
            end
            n += 1
            mf, mr = e.meilleur
            ecart_moyen += (e.valeurs[mf][mr] - e.valeurs[famille][0]).abs
            unless premier
              ecart_moyen_2 += (e.valeurs[mf][mr] - e.valeurs[famille][0]).abs
              n2 += 1
            end
          }

          s = "#{vrai} rights, #{n-vrai} wrongs (#{'%.2f' % (100*(vrai.to_f/n))} %)\n"
          s << "mean difference between the best score and the correct answer: #{'%.2f' % (ecart_moyen/n)}\n"
          s << "mean difference between the best score and the correct answer, if we made a mistake: #{'%.2f' % (ecart_moyen_2/n2)}\n"

        end

        # Affiche un motif
        def self.un_motif(motif, eval, famille, rot)
          f, r = eval.meilleur
          premier = (f == famille && r == rot)
          s =  "Motif: #{motif} (#{premier ? 'succes' : 'echec'}) #{famille} #{rot}\n"
          s << eval.to_s
        end

        def self.separateur
          "\n"
        end

      end


      class EcartsAvecOptimum < Report

        def self.un_motif(motif, eval)
          motif =~ FAMILY_R or raise 'nom de motif incorrect'
          famille = $1
          s =  "Motif: #{motif}\n"
          s << "Rang: #{eval.rang(famille, 0)}\n"
        end

        def self.summary(h)
          count = Array.new(Configuration.nombre_de_possibilites, 0)
          h.each { |motif, e|
            motif =~ FAMILY_R or raise 'nom de motif incorrect'
            famille = $1
            count[e.rang(famille, 0)-1] += 1
          }

          s = "Nombre de motifs obtenant ce rang: \n" 
          count.each_with_index { |n, i|
            s << "#{i+1}\t#{n}\n"
          }
          return s
        end

      end


      class ConnaissantLeStacking < Report

        def self.un_motif(motif, eval)
          motif =~ FAMILY_R or raise 'nom de motif incorrect'
          famille = $1
          f, r = eval.meilleur_pour_la_rotation(0)
          premier = (f == famille && r == 0)
          s =  "Motif: #{motif} (#{premier ? 'succes' : 'echec'})\n"
          s << eval.to_s.split("\n")[0..3].join("\n") + "\n"
        end

        def self.summary(h)
          vrai = 0

          n = 0
          h.each { |motif, e|
            motif =~ FAMILY_R or raise 'nom de motif incorrect'
            famille = $1
            f, r = e.meilleur_pour_la_rotation(0)
            premier = (f == famille && r == 0)
            if premier
              vrai += 1
            end
            n += 1
          }

          "#{vrai} succ�s, #{n-vrai} echecs (#{'%.2f' % (100*(vrai.to_f/n))} %)\n"
        end

      end

      class PourChaqueRotation < Report

        def self.un_motif(motif, eval)
          motif =~ FAMILY_R or raise 'nom de motif incorrect'
          famille = $1
          s = "#{motif}: "
          Configuration.each_r { |i|
            f, r = eval.meilleur_pour_la_rotation(i)
            s << f
          }
          return s
        end

        def self.summary(h)
          ''
        end

      end

    end
  end
end
