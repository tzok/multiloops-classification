module Classification
  module ThreeWay
    module Evaluations

      class EvalMultiple < EvalPlusRangs

        def calcule(motifs, my_coefs = nil)
          # verifie que les motifs sont bien
          # tous dans la meme rotation au depart
          motifs.each { |m|
            assert { m.brins[0].debut == -1 ||
              (m.brins[0].debut < m.brins[1].debut &&
               m.brins[0].debut < m.brins[2].debut) }
          }

          # calcule les tests
          @eval = {}
          @tests.each_value { |test|
            @eval[test.nom] ||= {}
            Configuration.each { |f, r|
              @eval[test.nom][f] ||= []

              sum = 0.0
              motifs.each { |motif|
                sum += test.calcule(motif, f, r)
              }
              sum /= motifs.size

              @eval[test.nom][f][r] = sum
            }
          }

          evalue(my_coefs)
        end

      end

    end
  end
end
